FLIX BUS MOBILE WEB APP AUTOMATION


This is the Java based UI automation framework using, Selenium 3.141.59, APPIUM 4.1.2, TestNG 7.1.0. 

Features:

1. This will validate the test and provider the TestNG report, 
2. With the complete logs and screenshots, 
3. It will provide the exception details steps and execution time.

Pre-Requisites:

1. Should have Java Jdk 1.8
2. Android SDK installed version 3.4
3. Install Appium and start the Appium server on default port 4723 to connect Appium proxy


Steps:

1. Download to the local machine
2. Import to the IDE as Maven project
3. Run Maven Clean
4. Run Maven Build
5. Open Android Emulator / Real device connect with USB to system and developer option enabled
6. Check the Device connectivity through adb devices command, for device connectivity.
7. Run the AutomationMobileweb.xml Run as "TestNG Suite" or
Can run from command prompt "java -cp <Project Path>\bin org.testng.TestNG testng.xml"

Replace the <Project Path>


Conclusion:

It will generate the TestNG default report in Test Output after complete the execution, Refresh the project for latest report.

Test-output->emailable-report.html to view execution result




