package com.MobileWebsiteBusinessFlows;

public class MobileWebLocators 
{
	/* Home page locators */
	public static String SourceBox ="//div[@data-e2e='departure-city-input-field']";
	public static String AutosuggestBox="//input[@class='smhc-input__field']";
	public static String Autosuggestname ="//button[@class='_18Kcp']";
	public static String destinationBox ="//div[@data-e2e='arrival-city-input-field']";
	public static String Calenderinput="//div[@class='_3pecu vjsUt']";
	//public static String destinationname ="//li[@class='notranslate _2AIFL'][1]";
	public static String clickclose="//button[@class='_3dr60']";
	public static String searchbutton ="//*[contains(text(),'Search')]";
	
	/* Search  page locators */

	public static String headerSearchSrccityname = "//span[@data-e2e='header-departure-city']";
	public static String headerSearchDescityname = "//span[@data-e2e='header-arrival-city']";
	public static String headerSearchdoj = "//div[@class='CollapsedSearchMask__bottomRow___1h4k0']";
	public static String selecttripbutton = "//button[@data-e2e='button-reserve-trip']";
	
	public static String AlternativeBus = "//div[@class='NearbyCitiesSuggestions__nearbyCitiesItem___2eBnk']";
}
