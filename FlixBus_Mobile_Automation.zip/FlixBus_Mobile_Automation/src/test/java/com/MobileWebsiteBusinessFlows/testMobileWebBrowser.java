package com.MobileWebsiteBusinessFlows;

import java.net.URL;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import java.util.*;
import java.awt.Desktop.Action;
import java.io.*;  

public class testMobileWebBrowser {

	WebDriver driver;
	DesiredCapabilities cap = new DesiredCapabilities();

	//project location path to set below to access configuration
	String path = "--\\Mobile\\src\\test\\java\\com\\MobileWebsiteBusinessFlows\\config.properties";


	public String source = "Berlin"; //source name from autosuggest
	public String destination ="Munich International Airport"; //Destination name from autosuggest
	public String DOJ ="10";//which day to select from calender

	@BeforeClass
	public void initSetupToRun() throws IOException{

		FileReader reader=new FileReader(path);  

		Properties p=new Properties();  
		p.load(reader);

		System.out.println("1)Device set to run :>> "+p.getProperty("Device")+"\n2)Android OS version set as :>>"+p.getProperty("MobileOSVersion")); 
		Reporter.log("1)Device set to run :>> "+p.getProperty("Device")+"\n2)Android OS version set as :>>"+p.getProperty("MobileOSVersion")); 

		String device = p.getProperty("Device");
		String Version = p.getProperty("MobileOSVersion");

		if(device.contains("Emulator"))
		{
			cap.setCapability("deviceName", "Android SDK built for x86");
		}
		else
		{
			cap.setCapability("deviceName", device);
		}
		cap.setCapability("platformName", "Android");
		cap.setCapability(CapabilityType.BROWSER_NAME, "Chrome"); 
		cap.setCapability(CapabilityType.VERSION, Version);
		driver = new RemoteWebDriver(new URL("http://127.0.0.1:4723/wd/hub"), cap);

		driver.get("https://global.flixbus.com");

	}


	@Test(priority = 1,enabled = true)
	public void testMobileWebsiteHomePage() throws IOException  {

		try {
			System.out.println(driver.getTitle());

			String Actualtitle = driver.getTitle();
			String Expectedtitle = "Bus travel through Europe | FlixBus";
			/* assertion for futher procceding to verify */
			Assert.assertEquals(Expectedtitle, Actualtitle);

			Reporter.log ("Home page title :: "+driver.getTitle());

			File file  = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(file, new File("--/Mobile/test-output/HOMEPAGE.jpg"));
			WebDriverWait wait = new WebDriverWait(driver, 10);

			driver.findElement(By.xpath(MobileWebLocators.SourceBox)).click();	
			WebElement elementsrc=wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'"+source+"')]")));
			System.out.println(elementsrc.getText());
			elementsrc.click();

			driver.findElement(By.xpath(MobileWebLocators.destinationBox)).click();


			WebElement element=wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'"+destination+"')]")));
			System.out.println(element.getText());
			element.click();

			driver.findElement(By.xpath("//div[@class='_3pecu vjsUt']")).click();

			WebElement elementdate=wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'"+DOJ+"')]")));
			System.out.println(elementdate.getText());
			elementdate.click();

			driver.findElement(By.xpath("//button[contains(text(),'Confirm')]")).click();

			driver.findElement(By.xpath(MobileWebLocators.searchbutton)).click();


			System.out.println("Validation complete for home landing page");
			Reporter.log("PASS :: Validation complete for home landing page");


		}
		catch(Exception ex)
		{
			Reporter.log("**FAIL :: Able to Successfully Test landing Page of  mobileWebsite :: "  +ex.getMessage());
		}

	}

	@Test(priority = 2,enabled = true)
	public void testSearchListingpage() throws IOException, Throwable  
	{
		WebDriverWait wait = new WebDriverWait(driver, 10);
		
		WebElement element = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(MobileWebLocators.headerSearchSrccityname)));
		System.out.println(element.getText());
		Reporter.log(element.getText());

		WebElement element1 = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(MobileWebLocators.headerSearchDescityname)));
		System.out.println(element1.getText());
		Reporter.log(element1.getText());

		WebElement element3 = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(MobileWebLocators.headerSearchdoj)));
		System.out.println(element3.getText());
		Reporter.log(element3.getText());

		Boolean isPresent = driver.findElements(By.xpath(MobileWebLocators.selecttripbutton)).size() > 0;
		if(isPresent==false)
		{

			System.out.println("Sorry! No bus available");
			WebElement element5=wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(MobileWebLocators.AlternativeBus)));

			Reporter.log("Sorry! No bus available");
			System.out.println("We have alternateSuggestion as below >> \n" +element5.getText());
			Reporter.log("We have alternateSuggestion as below >> \n" +element5.getText());

			element5.click();

		}
		else 
		{

			WebElement element4=wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(MobileWebLocators.selecttripbutton)));
			System.out.println("We have trip available to book");
			
			element4.click();
			
		}

		System.out.println("PASS :: Successfully land on SearchPage");
		Reporter.log("PASS :: Successfully land on SearchPage");

		File file  = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(file, new File("--/Mobile/test-output/SRPPAGE.jpg"));
	}

	@Test(priority = 3,enabled = true)
	public void testSelectTrip() throws IOException, Throwable  
	{
		//Code for selecting Seat.
	}

	@Test(priority = 4,enabled = true)
	public void testPassengerInfoPage() throws IOException, Throwable  
	{
		//Code for Passenger infopage
	}

	@Test(priority = 5,enabled = true)
	public void testSeatReservationPage() throws IOException, Throwable  
	{
		//Code for SearReservationPage.
	}


	@AfterClass
	public void closeBrowser()
	{
		//driver.close();
		System.out.println("Able to successfully close mobilewebsite");
		Reporter.log("Able to successfully close mobilewebsite");
	}

}
